# Experimental Raw data

Raw JSON data are available for this experiment.
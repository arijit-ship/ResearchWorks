# About

Even though the time-evolution gate is noise-free XY-Hamiltonian (`xy-iss`) in this experiment, identity scaling is applied to it during redundant circuit runs, which is unnecessary.

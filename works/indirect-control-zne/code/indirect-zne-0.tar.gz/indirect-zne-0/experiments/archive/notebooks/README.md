# The experminetal result for ZNE in indirect-control system
---